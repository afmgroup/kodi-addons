"""Kodi-local streaming service. Nothing listens on the LAN."""
import hmac
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

import xbmc
import xbmcaddon

from resources.lib.auth import proxy_key
from resources.lib.graph import download
from resources.lib.stream import stream

PORT = 57443
KEY = ""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        pass  # Do not log URL parameters or sensitive identifiers.

    def do_HEAD(self):
        self.handle_read(is_head=True)

    def do_GET(self):
        self.handle_read(is_head=False)

    def handle_read(self, is_head=False):
        parsed = urlsplit(self.path)
        if parsed.path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", "2")
            self.end_headers()
            if not is_head:
                self.wfile.write(b"OK")
            return
        valid = re.fullmatch(r"/play/([^/]+)/([^/]+)", parsed.path)
        params = parse_qs(parsed.query)
        key = params.get("key", [""])[0]
        if not valid or not key or not hmac.compare_digest(key, KEY):
            self.send_error(403, "Forbidden")
            return
        drive, item = (unquote(value) for value in valid.groups())
        if not (1 <= len(drive) <= 160 and 1 <= len(item) <= 160):
            self.send_error(400, "Invalid item")
            return
        addon = xbmcaddon.Addon("plugin.video.tvhonedrive")
        client_id = addon.getSetting("client_id").strip()
        if not client_id:
            self.send_error(503, "Microsoft app not configured")
            return
        try:
            if is_head:
                _url, size = download(client_id, drive, item)
                self.send_response(200)
                self.send_header("Content-Type", "video/x-matroska")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(size))
                self.end_headers()
            else:
                stream(self, client_id, drive, item,
                       self.headers.get("Range", ""), download)
        except Exception:
            xbmc.log("[tvh-onedrive] Playback request failed", xbmc.LOGWARNING)
            # Responses may already have been written by the streaming method.
            self.close_connection = True


def main():
    global KEY
    KEY = proxy_key()
    monitor = xbmc.Monitor()
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        xbmc.log("[tvh-onedrive] Loopback port unavailable", xbmc.LOGWARNING)
        return
    server.daemon_threads = True
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    xbmc.log("[tvh-onedrive] Secure loopback playback service active", xbmc.LOGINFO)
    while not monitor.abortRequested():
        if monitor.waitForAbort(1.0):
            break
    server.shutdown()
    server.server_close()


if __name__ == "__main__":
    main()
