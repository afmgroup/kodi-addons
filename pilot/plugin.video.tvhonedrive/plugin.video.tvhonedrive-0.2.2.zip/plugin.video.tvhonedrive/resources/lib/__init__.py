# Python Kodi add-on helper package. No credentials checked into source.
