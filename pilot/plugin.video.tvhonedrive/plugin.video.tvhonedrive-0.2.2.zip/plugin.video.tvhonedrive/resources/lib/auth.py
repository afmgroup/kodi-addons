"""Microsoft OAuth device flow and credential storage. Kodi/Android Python stdlib only.

Never log or display access tokens, refresh tokens, or download URLs.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
import re
from pathlib import Path
import secrets
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

SCOPES = "offline_access Files.Read.All User.Read"
IDENTITY = "https://login.microsoftonline.com/consumers/oauth2/v2.0"
REFRESH_EARLY_SECONDS = 90


class AuthError(Exception):
    pass


def data_dir() -> Path:
    import xbmcvfs  # only available inside Kodi
    folder = Path(xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.tvhonedrive"
    ))
    folder.mkdir(parents=True, exist_ok=True)
    try:
        folder.chmod(0o700)
    except OSError:
        pass  # Android shared storage may not support chmod
    return folder


def token_file() -> Path:
    return data_dir() / "tokens.json"


def load_tokens() -> dict:
    path = token_file()
    if not path.exists():
        return {}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_tokens(token: dict) -> None:
    if not token.get("access_token") or not token.get("refresh_token"):
        raise AuthError("Microsoft did not return the required OAuth tokens")
    payload = {
        "access_token": str(token["access_token"]),
        "refresh_token": str(token["refresh_token"]),
        "expires_at": time.time() + int(token.get("expires_in", 3600)),
    }
    path = token_file()
    tmp = path.with_name(path.name + "." + secrets.token_hex(6) + ".tmp")
    fd = os.open(str(tmp), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, separators=(",", ":"))
        os.replace(tmp, path)
        try:
            path.chmod(0o600)
        except OSError:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


@contextmanager
def token_lock():
    """Coordinate refreshes between Kodi plugin and service on Android or Windows."""
    path = data_dir() / "token-refresh.lock"
    with path.open("a+b") as lock:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        if os.name == "nt":
            import msvcrt
            lock.seek(0)
            if not lock.read(1):
                lock.write(b"0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _form(url: str, fields: dict, timeout: float = 30) -> dict:
    data = urlencode(fields).encode("utf-8")
    request = Request(url, data=data, method="POST",
                      headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urlopen(request, timeout=timeout) as response:
            body = response.read(1024 * 1024)
    except HTTPError as exc:
        try:
            error_data = json.loads(exc.read(4096).decode("utf-8"))
            error = error_data.get("error", "")
        except (ValueError, UnicodeError):
            error = ""
        if error in ("authorization_pending", "slow_down", "authorization_declined",
                     "expired_token", "bad_verification_code"):
            return {"error": error}
        detail = ""
        try:
            description = error_data.get("error_description", "")
            code_match = re.search(r"AADSTS[0-9]+", description)
            if code_match:
                detail = ", " + code_match.group(0)
        except (NameError, TypeError):
            pass
        raise AuthError(f"Microsoft sign-in failed (HTTP {exc.code}{detail}). Check app account types and public client flows.") from None
    except (OSError, URLError) as exc:
        raise AuthError("Could not contact Microsoft sign-in service") from exc
    try:
        obj = json.loads(body)
    except ValueError as exc:
        raise AuthError("Microsoft sign-in returned invalid JSON") from exc
    if not isinstance(obj, dict):
        raise AuthError("Microsoft sign-in returned an unexpected response")
    return obj


def device_authorize(client_id: str, on_code, cancelled) -> None:
    """User-triggered, input-device-friendly Microsoft sign-in."""
    if not client_id:
        raise AuthError("Configure the Microsoft application ID first")
    issued = _form(f"{IDENTITY}/devicecode",
                   {"client_id": client_id, "scope": SCOPES})
    if "device_code" not in issued or "user_code" not in issued:
        raise AuthError("Microsoft did not supply a device code")
    on_code(issued.get("verification_uri", "https://microsoft.com/devicelogin"),
            issued["user_code"])
    interval = max(5, int(issued.get("interval", 5)))
    deadline = time.monotonic() + int(issued.get("expires_in", 900))
    next_poll = time.monotonic() + interval
    while time.monotonic() < deadline:
        if cancelled():
            raise AuthError("Microsoft sign-in cancelled")
        if time.monotonic() < next_poll:
            time.sleep(0.5)
            continue
        response = _form(f"{IDENTITY}/token", {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "client_id": client_id,
            "device_code": issued["device_code"],
        })
        error = response.get("error")
        if not error and response.get("access_token"):
            with token_lock():
                _save_tokens(response)
            return
        if error == "slow_down":
            interval += 5
        elif error != "authorization_pending":
            raise AuthError("Microsoft sign-in was declined or expired")
        next_poll = time.monotonic() + interval
    raise AuthError("Microsoft sign-in code expired")


def access_token(client_id: str, *, force_refresh: bool = False) -> str:
    if not client_id:
        raise AuthError("Microsoft application ID is not configured")
    cached = load_tokens()
    if (not force_refresh and cached.get("access_token") and
            float(cached.get("expires_at", 0)) > time.time() + REFRESH_EARLY_SECONDS):
        return cached["access_token"]
    with token_lock():
        current = load_tokens()
        if (not force_refresh and current.get("access_token") and
                float(current.get("expires_at", 0)) > time.time() + REFRESH_EARLY_SECONDS):
            return current["access_token"]
        refresh = current.get("refresh_token")
        if not refresh:
            raise AuthError("Sign in to your Microsoft account first")
        response = _form(f"{IDENTITY}/token", {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "refresh_token": refresh,
            "scope": SCOPES,
        })
        if not response.get("refresh_token"):
            response["refresh_token"] = refresh
        _save_tokens(response)
        return str(response["access_token"])


def sign_out() -> None:
    with token_lock():
        token_file().unlink(missing_ok=True)


def proxy_key() -> str:
    """Random local bearer value; never the Microsoft OAuth credential."""
    path = data_dir() / "proxy.key"
    try:
        return path.read_text(encoding="ascii").strip()
    except FileNotFoundError:
        pass
    value = secrets.token_urlsafe(32)
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return path.read_text(encoding="ascii").strip()
    with os.fdopen(fd, "w", encoding="ascii") as stream:
        stream.write(value)
    return value
