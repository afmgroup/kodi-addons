"""Small, strictly read-only Microsoft Graph client for OneDrive Personal."""
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

from .auth import access_token

ROOT = "https://graph.microsoft.com/v1.0"


class GraphError(Exception):
    pass


def get(client_id, endpoint):
    if endpoint.startswith("/"):
        url = ROOT + endpoint
    elif endpoint.startswith(ROOT + "/"):
        url = endpoint
    else:
        raise GraphError("Untrusted Graph URL")
    for attempt in range(2):
        try:
            token = access_token(client_id, force_refresh=bool(attempt))
            request = Request(url, headers={"Authorization": "Bearer " + token})
            with urlopen(request, timeout=30) as reply:
                obj = json.loads(reply.read(2 * 1024 * 1024))
            if not isinstance(obj, dict):
                raise GraphError("Unexpected Microsoft Graph response")
            return obj
        except HTTPError as error:
            if error.code == 401 and attempt == 0:
                continue
            raise GraphError("Microsoft Graph HTTP " + str(error.code)) from None
        except (URLError, ValueError, TimeoutError) as error:
            raise GraphError("Microsoft Graph request failed") from error
    raise GraphError("Microsoft sign-in has expired")


def children(client_id, endpoint):
    found = []
    while endpoint:
        page = get(client_id, endpoint)
        found.extend(item for item in page.get("value", []) if isinstance(item, dict))
        if len(found) > 5000:
            raise GraphError("Folder is too large")
        endpoint = page.get("@odata.nextLink")
        if endpoint and not str(endpoint).startswith(ROOT + "/"):
            raise GraphError("Untrusted next-page URL")
    return found


def owner_root(client_id, path):
    folder = path.strip("/")
    if not folder or ".." in folder.split("/"):
        raise GraphError("Invalid archive path")
    return children(client_id, "/me/drive/root:/" + quote(folder, safe="/") + ":/children")


def folder_children(client_id, drive_id, item_id):
    return children(client_id, "/drives/" + quote(drive_id, safe="") +
                    "/items/" + quote(item_id, safe="") + "/children")


def download(client_id, drive_id, item_id):
    info = get(client_id, "/drives/" + quote(drive_id, safe="") +
               "/items/" + quote(item_id, safe=""))
    url = info.get("@microsoft.graph.downloadUrl")
    size = info.get("size")
    if not isinstance(url, str) or urlsplit(url).scheme != "https":
        raise GraphError("OneDrive download URL unavailable")
    if not isinstance(size, int) or size < 0:
        raise GraphError("OneDrive size unavailable")
    return url, size


def read_manifest(client_id, drive_id, item_id):
    url, size = download(client_id, drive_id, item_id)
    if size > 131072:
        raise GraphError("Manifest too large")
    with urlopen(Request(url), timeout=30) as reply:
        raw = reply.read(131073)
    if len(raw) > 131072:
        raise GraphError("Manifest too large")
    result = json.loads(raw)
    if not isinstance(result, dict) or result.get("schema") != 1:
        raise GraphError("Invalid archive manifest")
    return result
