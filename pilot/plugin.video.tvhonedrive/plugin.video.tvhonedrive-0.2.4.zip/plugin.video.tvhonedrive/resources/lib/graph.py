"""Small, strictly read-only Microsoft Graph client for OneDrive Personal."""
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

from .auth import access_token

ROOT = "https://graph.microsoft.com/v1.0"


class GraphError(Exception):
    pass


def get(client_id, endpoint):
    if endpoint.startswith("/"):
        url = ROOT + endpoint
    elif endpoint.startswith(ROOT + "/"):
        url = endpoint
    else:
        raise GraphError("Untrusted Graph URL")
    for attempt in range(2):
        try:
            token = access_token(client_id, force_refresh=bool(attempt))
            request = Request(url, headers={"Authorization": "Bearer " + token})
            with urlopen(request, timeout=30) as reply:
                obj = json.loads(reply.read(2 * 1024 * 1024))
            if not isinstance(obj, dict):
                raise GraphError("Unexpected Microsoft Graph response")
            return obj
        except HTTPError as error:
            if error.code == 401 and attempt == 0:
                continue
            raise GraphError("Microsoft Graph HTTP " + str(error.code)) from None
        except (URLError, ValueError, TimeoutError) as error:
            raise GraphError("Microsoft Graph request failed") from error
    raise GraphError("Microsoft sign-in has expired")


def children(client_id, endpoint):
    found = []
    while endpoint:
        page = get(client_id, endpoint)
        found.extend(item for item in page.get("value", []) if isinstance(item, dict))
        if len(found) > 5000:
            raise GraphError("Folder is too large")
        endpoint = page.get("@odata.nextLink")
        if endpoint and not str(endpoint).startswith(ROOT + "/"):
            raise GraphError("Untrusted next-page URL")
    return found


def owner_root(client_id, path):
    folder = path.strip("/")
    if not folder or ".." in folder.split("/"):
        raise GraphError("Invalid archive path")
    return children(client_id, "/me/drive/root:/" + quote(folder, safe="/") + ":/children")


def sharing_token(sharing_url):
    """Microsoft Graph's base64url share identifier; never persist it in logs."""
    import base64
    value = str(sharing_url).strip()
    if not value or len(value) > 4096:
        raise GraphError("Configure a valid private OneDrive sharing link")
    try:
        parsed = urlsplit(value)
    except ValueError as exc:
        raise GraphError("Invalid OneDrive sharing link") from None
    try:
        valid_port = parsed.port in (None, 443)
    except ValueError:
        raise GraphError("Invalid OneDrive sharing link") from None
    if (parsed.scheme != "https" or parsed.username or parsed.password or
            not valid_port or (parsed.hostname or "").lower() not in
            {"1drv.ms", "www.1drv.ms", "onedrive.live.com",
             "onedrive.com", "www.onedrive.com"}):
        raise GraphError("Use an HTTPS OneDrive Personal sharing link")
    return "u!" + base64.urlsafe_b64encode(value.encode("utf-8")).decode("ascii").rstrip("=")


def shared_archive(client_id, sharing_url, archive_subfolder="TVHeadend"):
    """Browse the archive under a folder explicitly shared with this account.

    No /sharedWithMe dependency. Recipient authorization is controlled by
    Microsoft: the sharing link and delegated Microsoft account must have
    access. Avoid attempting to redeem or escalate permissions silently.
    """
    path = str(archive_subfolder).strip("/")
    parts = path.split("/") if path else []
    if any(part in ("", ".", "..") for part in parts) or len(parts) > 8:
        raise GraphError("Invalid shared archive subfolder")
    root = get(client_id, "/shares/" + sharing_token(sharing_url) + "/driveItem")
    root_item = root.get("remoteItem", root)
    if not isinstance(root_item.get("folder"), dict):
        raise GraphError("The shared OneDrive link must point to a folder")
    reference = root_item.get("parentReference") or {}
    drive_id = reference.get("driveId")
    folder_id = root_item.get("id")
    if not drive_id or not folder_id:
        raise GraphError("Microsoft did not return the shared folder identity")
    if parts and str(root_item.get("name", "")).casefold() == parts[0].casefold():
        parts = parts[1:]
    for part in parts:
        listed = folder_children(client_id, drive_id, folder_id)
        matches = [item for item in listed
                   if isinstance(item.get("folder"), dict) and item.get("name") == part]
        if len(matches) != 1:
            raise GraphError("Shared archive subfolder not found: " + part)
        folder = matches[0]
        drive_id = (folder.get("parentReference") or {}).get("driveId") or drive_id
        folder_id = folder.get("id")
        if not folder_id:
            raise GraphError("Shared archive folder has no identifier")
    return folder_children(client_id, drive_id, folder_id)


def folder_children(client_id, drive_id, item_id):
    return children(client_id, "/drives/" + quote(drive_id, safe="") +
                    "/items/" + quote(item_id, safe="") + "/children")


def download(client_id, drive_id, item_id):
    info = get(client_id, "/drives/" + quote(drive_id, safe="") +
               "/items/" + quote(item_id, safe=""))
    url = info.get("@microsoft.graph.downloadUrl")
    size = info.get("size")
    if not isinstance(url, str) or urlsplit(url).scheme != "https":
        raise GraphError("OneDrive download URL unavailable")
    if not isinstance(size, int) or size < 0:
        raise GraphError("OneDrive size unavailable")
    return url, size


def read_manifest(client_id, drive_id, item_id):
    url, size = download(client_id, drive_id, item_id)
    if size > 131072:
        raise GraphError("Manifest too large")
    with urlopen(Request(url), timeout=30) as reply:
        raw = reply.read(131073)
    if len(raw) > 131072:
        raise GraphError("Manifest too large")
    result = json.loads(raw)
    if not isinstance(result, dict) or result.get("schema") != 1:
        raise GraphError("Invalid archive manifest")
    return result
