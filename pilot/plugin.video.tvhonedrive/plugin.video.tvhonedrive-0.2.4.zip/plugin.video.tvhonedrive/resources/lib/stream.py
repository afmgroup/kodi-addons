"""Byte-range streaming from OneDrive through Kodi's loopback HTTP endpoint.

Fetches small ranges and renews temporary Graph download URLs on failure.
No user credentials or preauthenticated URLs are returned to callers.
"""
import re
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

CHUNK = 32 * 1024 * 1024
READ_BLOCK = 128 * 1024


def parse_range(header, size):
    """Return inclusive (start, end), or raise ValueError for malformed ranges."""
    if size < 1:
        raise ValueError("Empty recording")
    if not header:
        return 0, size - 1, False
    match = re.fullmatch(r"bytes=(\d*)-(\d*)", header.strip())
    if not match:
        raise ValueError("Unsupported byte range")
    left, right = match.groups()
    if not left and not right:
        raise ValueError("Empty byte range")
    if not left:
        suffix = int(right)
        if suffix <= 0:
            raise ValueError("Invalid suffix length")
        start = max(0, size - suffix)
        end = size - 1
    else:
        start = int(left)
        end = min(size - 1, int(right)) if right else size - 1
    if start >= size or start > end:
        raise ValueError("Unsatisfiable range")
    return start, end, True


def stream(handler, client_id, drive_id, item_id, requested_range, resolver,
           opener=urlopen):
    """Transfer ranges. Only explicit gateway mode attaches private HTTP headers."""

    import xbmc
    from urllib.error import HTTPError
    from socket import timeout as SocketTimeout

    resolved = resolver(client_id, drive_id, item_id)
    if len(resolved) == 2:
        url, size = resolved
        private_headers = {}
    elif len(resolved) == 3:
        url, size, private_headers = resolved
    else:
        raise ValueError("Invalid upstream resolver result")
    try:
        start, end, partial = parse_range(requested_range, size)
    except ValueError:
        handler.send_response(416)
        handler.send_header("Content-Range", "bytes */" + str(size))
        handler.send_header("Content-Length", "0")
        handler.end_headers()
        return
    status = 206 if partial else 200
    handler.send_response(status)
    handler.send_header("Content-Type", "video/x-matroska")
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Length", str(end - start + 1))
    handler.send_header("Cache-Control", "no-store")
    if partial:
        handler.send_header("Content-Range", f"bytes {start}-{end}/{size}")
    handler.end_headers()

    offset = start
    attempts = 0
    while offset <= end:
        chunk_end = min(end, offset + CHUNK - 1)
        wanted = chunk_end - offset + 1
        upstream = None
        try:
            headers = {"Range": f"bytes={offset}-{chunk_end}", **private_headers}
            request = Request(url, headers=headers)
            upstream = opener(request, timeout=35)
            code = upstream.status
            remote_range = upstream.headers.get("Content-Range", "")
            if code == 206:
                prefix = re.match(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", remote_range)
                if not prefix or int(prefix.group(1)) != offset or int(prefix.group(2)) < chunk_end:
                    raise OSError("Upstream returned incorrect range")
            elif code != 200 or offset != 0 or chunk_end != size - 1:
                raise OSError("Upstream did not honor the requested byte range")
            count = 0
            while count < wanted:
                block = upstream.read(min(READ_BLOCK, wanted - count))
                if not block:
                    raise OSError("OneDrive ended the stream prematurely")
                try:
                    handler.wfile.write(block)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    return  # Kodi sought or stopped; no error and no token leakage
                count += len(block)
                offset += len(block)
            attempts = 0
        except (HTTPError, URLError, OSError, SocketTimeout) as exc:
            attempts += 1
            if attempts > 3:
                xbmc.log("[tvh-onedrive] Streaming exhausted retries", xbmc.LOGWARNING)
                return
            # Temporary OneDrive URLs may expire; always fetch a fresh link.
            try:
                resolved = resolver(client_id, drive_id, item_id)
                url, latest_size = resolved[:2]
                if len(resolved) == 3:
                    private_headers = resolved[2]
                if latest_size != size:
                    xbmc.log("[tvh-onedrive] Recording changed during playback", xbmc.LOGWARNING)
                    return
            except Exception:
                return
            time.sleep(min(2 ** (attempts - 1), 4))
        finally:
            if upstream is not None:
                upstream.close()
