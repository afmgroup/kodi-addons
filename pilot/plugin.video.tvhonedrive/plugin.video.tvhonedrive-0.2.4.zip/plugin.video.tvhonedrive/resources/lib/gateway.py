"""Kodi client for separately approved, link-only read-only archive gateway.

Never authenticate Microsoft users here, never send a bearer key in a URL, and
never log or display the URL fragment containing the capability.
"""
import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

UUID = re.compile(r"[0-9a-f]{32}\Z")
CAPABILITY = re.compile(r"[A-Za-z0-9_-]{40,120}\Z")
SAFE_PATH = re.compile(r"/[A-Za-z0-9/_-]{0,120}\Z")
MAX_RESPONSE = 1024 * 1024


class GatewayError(Exception):
    pass


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        # Bearer credentials must not follow a server-controlled redirect.
        return None


_OPENER = build_opener(NoRedirects())


def parse_link(raw):
    """Return (safe HTTPS API base, bearer token). Empty input denies access."""
    if not isinstance(raw, str) or len(raw) > 2048:
        raise GatewayError("Invalid archive access link")
    try:
        u = urlsplit(raw.strip())
        port = u.port
    except ValueError:
        raise GatewayError("Invalid archive access link") from None
    if (u.scheme != "https" or not u.hostname or u.username or u.password or
            port not in (None, 443) or u.query or
            not SAFE_PATH.fullmatch(u.path or "/") or
            ".." in u.path or "//" in u.path):
        raise GatewayError("Archive access link must use a trusted HTTPS address")
    try:
        options = parse_qs(u.fragment, strict_parsing=True)
    except ValueError:
        raise GatewayError("Invalid archive access link") from None
    if set(options) != {"key"} or len(options["key"]) != 1:
        raise GatewayError("Archive access link is missing its private key")
    secret = options["key"][0]
    if not CAPABILITY.fullmatch(secret):
        raise GatewayError("Invalid archive access key")
    return u._replace(fragment="", query="").geturl().rstrip("/"), secret


def is_configured(raw):
    return bool(str(raw).strip())


def _get_json(base, secret, endpoint):
    request = Request(base + endpoint, headers={
        "Authorization": "Bearer " + secret,
        "Accept": "application/json",
    })
    try:
        with _OPENER.open(request, timeout=20) as response:
            if response.status != 200:
                raise GatewayError("Archive gateway unavailable")
            raw = response.read(MAX_RESPONSE + 1)
    except HTTPError as exc:
        if exc.code in (401, 403):
            raise GatewayError("Archive access denied; request an approved access link") from None
        raise GatewayError("Archive gateway HTTP " + str(exc.code)) from None
    except (URLError, OSError, TimeoutError):
        raise GatewayError("Could not connect to the archive gateway") from None
    if len(raw) > MAX_RESPONSE:
        raise GatewayError("Archive listing too large")
    try:
        return json.loads(raw)
    except (ValueError, UnicodeError):
        raise GatewayError("Invalid archive gateway response") from None


def recordings(raw_link):
    """Only authorized, server-approved entries are returned."""
    base, secret = parse_link(raw_link)
    data = _get_json(base, secret, "/v1/recordings")
    values = data.get("recordings") if isinstance(data, dict) else None
    if not isinstance(values, list) or len(values) > 5000:
        raise GatewayError("Invalid archive listing")
    result = []
    seen = set()
    for value in values:
        if not isinstance(value, dict):
            continue
        ident = value.get("id")
        title = value.get("title")
        size = value.get("size")
        if (not isinstance(ident, str) or not UUID.fullmatch(ident) or
                ident in seen or not isinstance(title, str) or
                type(size) is not int or size <= 0):
            continue
        seen.add(ident)
        result.append({"id": ident, "title": title[:180], "size": size})
    return result


def resolve_file(raw_link, ident):
    """Return HTTPS stream URL, size, private headers; never return token in URL."""
    if not isinstance(ident, str) or not UUID.fullmatch(ident):
        raise GatewayError("Invalid recording identifier")
    base, secret = parse_link(raw_link)
    url = base + "/v1/recordings/" + ident
    try:
        with _OPENER.open(Request(url, method="HEAD", headers={
                "Authorization": "Bearer " + secret}), timeout=20) as response:
            if response.status != 200:
                raise GatewayError("Archive recording unavailable")
            size = int(response.headers.get("Content-Length", "0"))
    except HTTPError as exc:
        if exc.code in (401, 403):
            raise GatewayError("Archive access denied") from None
        raise GatewayError("Archive recording unavailable") from None
    except (URLError, OSError, ValueError, TimeoutError):
        raise GatewayError("Archive recording unavailable") from None
    if size <= 0 or size >= 10 ** 12:
        raise GatewayError("Invalid archive recording size")
    return url, size, {"Authorization": "Bearer " + secret}


def safe_open(request, timeout=35):
    """Do not forward archive access keys across HTTP redirects."""
    return _OPENER.open(request, timeout=timeout)
