"""Browse private TVHeadend OneDrive recordings; Microsoft sign-in is per Kodi device."""
import sys
import secrets
import time
from urllib.parse import parse_qs, urlencode, quote
from urllib.request import urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import auth, graph, gateway

ADDON = xbmcaddon.Addon("plugin.video.tvhonedrive")
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PORT = 57443


def uri(action, **arguments):
    return BASE + "?" + urlencode({"action": action, **arguments})


def entry(label, action, folder=True, playable=False, **arguments):
    item = xbmcgui.ListItem(label=label)
    if playable:
        item.setProperty("IsPlayable", "true")
        item.setMimeType("video/x-matroska")
        item.setContentLookup(False)
    xbmcplugin.addDirectoryItem(HANDLE, uri(action, **arguments), item, isFolder=folder)


def finish(success=True):
    xbmcplugin.endOfDirectory(HANDLE, succeeded=success, cacheToDisc=False)


def home():
    has_link = gateway.is_configured(ADDON.getSetting("archive_gateway_link"))
    owner_signed_in = bool(auth.load_tokens().get("refresh_token"))
    # The public add-on itself is visible in Kodi, but an unapproved device
    # must not receive a directory entry or metadata for archive recordings.
    if has_link or owner_signed_in:
        entry("Archive recordings", "root")
    if has_link:
        entry("Forget this device / Pair again", "forget")
    if not has_link:
        entry("Pair this device (8-digit code)", "pair")
        entry("Microsoft owner account sign-in (" +
              ("Signed in" if owner_signed_in else "Not signed in") + ")", "login")
    entry("Connection diagnostics", "diagnostics")
    if owner_signed_in:
        entry("Sign out Microsoft account", "logout")
    entry("Configure approved archive access", "settings")
    finish()


def forget_device():
    """Delete this Kodi profile's saved link only; never revoke server-side."""
    current = ADDON.getSetting("archive_gateway_link").strip()
    if not current:
        finish()
        return
    if xbmcgui.Dialog().yesno(
            "Forget archive device",
            "Clear this device's saved access?",
            "Server authorization is not revoked."):
        ADDON.setSetting("archive_gateway_link", "")
        xbmcgui.Dialog().ok("Archive device", "Saved access cleared.",
                            "Open Pair this device to reconnect.")
    finish()


def pair_device():
    """Pair on the Kodi screen; only the short code is shown to the viewer."""
    if gateway.is_configured(ADDON.getSetting("archive_gateway_link")):
        xbmcgui.Dialog().ok("Archive pairing",
                            "This device already has archive access.")
        finish()
        return
    secret = secrets.token_urlsafe(36)
    try:
        code, lifetime = gateway.pair_start(secret)
    except gateway.GatewayError as exc:
        xbmcgui.Dialog().ok("Archive pairing", str(exc))
        finish(False)
        return
    dialog = xbmcgui.DialogProgress()
    dialog.create("Pair TVHeadend archive",
                  "Give this 8-digit code to admin:\n" + code)
    approved = False
    try:
        until = time.monotonic() + lifetime
        monitor = xbmc.Monitor()
        while time.monotonic() < until and not dialog.iscanceled():
            remaining = max(0, int(until - time.monotonic()))
            dialog.update(max(0, min(99, 100 * (lifetime - remaining) // lifetime)),
                          "Pair code: " + code +
                          "\nSend code to administrator" +
                          "\nExpires in " + str(remaining) + "s")
            state = gateway.pair_status(secret)
            if state == "approved":
                # Server knows only SHA-256(secret); this long credential is
                # saved only locally, never displayed or included in logs.
                ADDON.setSetting("archive_gateway_link",
                                 gateway.PAIR_BASE + "#key=" + secret)
                approved = True
                break
            if state in ("expired", "denied"):
                break
            if monitor.waitForAbort(3):
                break
    except gateway.GatewayError as exc:
        dialog.close()
        xbmcgui.Dialog().ok("Archive pairing", str(exc))
        finish(False)
        return
    finally:
        dialog.close()
    if approved:
        xbmcgui.Dialog().ok("Archive pairing", "Device approved.",
                            "Open Archive recordings.")
    else:
        xbmcgui.Dialog().ok("Archive pairing",
                            "Pairing ended without approval. You can try again.")
    finish()


def login():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Microsoft OneDrive", "Requesting sign-in code...")
    try:
        def show_code(url, code):
            dialog.update(0, "On your phone or computer visit:\n" + str(url) +
                          "\n\nEnter this code: " + str(code) +
                          "\n\nWaiting for authorization...")
        auth.device_authorize(ADDON.getSetting("client_id").strip(),
                              show_code, dialog.iscanceled)
        xbmcgui.Dialog().ok("OneDrive", "Sign-in completed successfully.")
    except auth.AuthError as exc:
        xbmcgui.Dialog().ok("OneDrive sign-in", str(exc))
    finally:
        dialog.close()
    finish()


def browse(folder=None, drive=None):
    client_id = ADDON.getSetting("client_id").strip()
    approved_link = ADDON.getSetting("archive_gateway_link").strip()
    if approved_link:
        try:
            # No folder/drive IDs from plugin URLs are accepted in link mode.
            if folder is not None or drive is not None:
                finish(False)
                return
            rows = gateway.recordings(approved_link)
            xbmcplugin.setContent(HANDLE, "files")
            for item in sorted(rows, key=lambda x: x["title"].lower()):
                entry(item["title"], "play", folder=False, playable=True,
                      item=item["id"], drive="gateway")
            finish()
        except gateway.GatewayError as exc:
            xbmcgui.Dialog().ok("Archive access", str(exc))
            finish(False)
        return
    if not auth.load_tokens().get("refresh_token"):
        xbmcgui.Dialog().ok("Archive access", "An approved link or owner sign-in is required.")
        finish(False)
        return
    try:
        if folder is None:
            shared_link = ADDON.getSetting("share_url").strip()
            if shared_link:
                records = graph.shared_archive(
                    client_id, shared_link, ADDON.getSetting("shared_subfolder"))
            else:
                records = graph.owner_root(client_id, ADDON.getSetting("archive_path"))
            # Owner/authorized Microsoft accounts should see the same flat
            # recording list as paired viewers, not the archive's storage tree.
            records = graph.archive_recordings(client_id, records)
        else:
            # Backward compatibility for a stale open Kodi directory entry.
            records = graph.folder_children(client_id, drive, folder)
        xbmcplugin.setContent(HANDLE, "files")
        for item in sorted(records, key=lambda x: (not bool(x.get("folder")),
                                                   x.get("name", "").lower())):
            name = item.get("name", "")
            identifier = item.get("id")
            drive_id = (item.get("parentReference") or {}).get("driveId") or drive
            if not identifier or not drive_id:
                continue
            if "folder" in item:
                entry(name, "folder", folder=True, item=identifier, drive=drive_id)
            elif item.get("archive_video") is True or name.lower().endswith(
                    (".mkv", ".mp4", ".ts")):
                entry(name, "play", folder=False, playable=True,
                      item=identifier, drive=drive_id)
        finish()
    except (auth.AuthError, graph.GraphError, OSError) as exc:
        xbmcgui.Dialog().ok("OneDrive archive", str(exc))
        finish(False)


def play(drive, item):
    approved_link = ADDON.getSetting("archive_gateway_link").strip()
    owner_signed_in = bool(auth.load_tokens().get("refresh_token"))
    if ((approved_link and drive != "gateway") or
            (not approved_link and (drive == "gateway" or not owner_signed_in))):
        xbmcgui.Dialog().ok("Archive access", "This Kodi device is not authorized.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        with urlopen("http://127.0.0.1:" + str(PORT) + "/health", timeout=2) as health:
            if health.status != 200:
                raise OSError("Streaming service unavailable")
        address = ("http://127.0.0.1:" + str(PORT) + "/play/" +
                   quote(drive, safe="") + "/" + quote(item, safe="") +
                   "?" + urlencode({"key": auth.proxy_key()}))
        video = xbmcgui.ListItem(path=address)
        video.setMimeType("video/x-matroska")
        video.setContentLookup(False)
        xbmcplugin.setResolvedUrl(HANDLE, True, video)
    except OSError:
        xbmcgui.Dialog().ok("OneDrive", "Local playback service is not running. Restart Kodi.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def diagnostics():
    try:
        with urlopen("http://127.0.0.1:" + str(PORT) + "/health", timeout=2) as reply:
            status = "Running" if reply.status == 200 else "Unavailable"
    except OSError:
        status = "Unavailable"
    connected = "Yes" if auth.load_tokens().get("refresh_token") else "No"
    link = ADDON.getSetting("archive_gateway_link").strip()
    mode = "Approved archive link configured" if link else (
        "Microsoft owner account" if connected == "Yes" else "Not authorized")
    xbmcgui.Dialog().ok("TVHeadend OneDrive", "Pilot build: 0.2.8" +
                         "\nLocal playback service: " + status +
                         "\nArchive access: " + mode +
                         "\nMicrosoft account connected: " + connected)
    finish()


def main():
    arguments = parse_qs(sys.argv[2][1:])
    action = arguments.get("action", ["home"])[0]
    if action == "home":
        home()
    elif action == "settings":
        ADDON.openSettings()
        finish()
    elif action == "pair":
        pair_device()
    elif action == "forget":
        forget_device()
    elif action == "login":
        login()
    elif action == "root":
        browse()
    elif action == "folder":
        browse(arguments.get("item", [""])[0], arguments.get("drive", [""])[0])
    elif action == "play":
        play(arguments.get("drive", [""])[0], arguments.get("item", [""])[0])
    elif action == "diagnostics":
        diagnostics()
    elif action == "logout":
        if xbmcgui.Dialog().yesno("OneDrive", "Sign out this Kodi device?"):
            auth.sign_out()
        finish()
    else:
        finish(False)


if __name__ == "__main__":
    main()
