"""Small, strictly read-only Microsoft Graph client for OneDrive Personal."""
import ast
from collections import deque
import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

from .auth import access_token

ROOT = "https://graph.microsoft.com/v1.0"


class GraphError(Exception):
    pass


def get(client_id, endpoint):
    if endpoint.startswith("/"):
        url = ROOT + endpoint
    elif endpoint.startswith(ROOT + "/"):
        url = endpoint
    else:
        raise GraphError("Untrusted Graph URL")
    for attempt in range(2):
        try:
            token = access_token(client_id, force_refresh=bool(attempt))
            request = Request(url, headers={"Authorization": "Bearer " + token})
            with urlopen(request, timeout=30) as reply:
                obj = json.loads(reply.read(2 * 1024 * 1024))
            if not isinstance(obj, dict):
                raise GraphError("Unexpected Microsoft Graph response")
            return obj
        except HTTPError as error:
            if error.code == 401 and attempt == 0:
                continue
            raise GraphError("Microsoft Graph HTTP " + str(error.code)) from None
        except (URLError, ValueError, TimeoutError) as error:
            raise GraphError("Microsoft Graph request failed") from error
    raise GraphError("Microsoft sign-in has expired")


def children(client_id, endpoint):
    found = []
    while endpoint:
        page = get(client_id, endpoint)
        found.extend(item for item in page.get("value", []) if isinstance(item, dict))
        if len(found) > 5000:
            raise GraphError("Folder is too large")
        endpoint = page.get("@odata.nextLink")
        if endpoint and not str(endpoint).startswith(ROOT + "/"):
            raise GraphError("Untrusted next-page URL")
    return found


def owner_root(client_id, path):
    folder = path.strip("/")
    if not folder or ".." in folder.split("/"):
        raise GraphError("Invalid archive path")
    return children(client_id, "/me/drive/root:/" + quote(folder, safe="/") + ":/children")


def sharing_token(sharing_url):
    """Microsoft Graph's base64url share identifier; never persist it in logs."""
    import base64
    value = str(sharing_url).strip()
    if not value or len(value) > 4096:
        raise GraphError("Configure a valid private OneDrive sharing link")
    try:
        parsed = urlsplit(value)
    except ValueError as exc:
        raise GraphError("Invalid OneDrive sharing link") from None
    try:
        valid_port = parsed.port in (None, 443)
    except ValueError:
        raise GraphError("Invalid OneDrive sharing link") from None
    if (parsed.scheme != "https" or parsed.username or parsed.password or
            not valid_port or (parsed.hostname or "").lower() not in
            {"1drv.ms", "www.1drv.ms", "onedrive.live.com",
             "onedrive.com", "www.onedrive.com"}):
        raise GraphError("Use an HTTPS OneDrive Personal sharing link")
    return "u!" + base64.urlsafe_b64encode(value.encode("utf-8")).decode("ascii").rstrip("=")


def shared_archive(client_id, sharing_url, archive_subfolder="TVHeadend"):
    """Browse the archive under a folder explicitly shared with this account.

    No /sharedWithMe dependency. Recipient authorization is controlled by
    Microsoft: the sharing link and delegated Microsoft account must have
    access. Avoid attempting to redeem or escalate permissions silently.
    """
    path = str(archive_subfolder).strip("/")
    parts = path.split("/") if path else []
    if any(part in ("", ".", "..") for part in parts) or len(parts) > 8:
        raise GraphError("Invalid shared archive subfolder")
    root = get(client_id, "/shares/" + sharing_token(sharing_url) + "/driveItem")
    root_item = root.get("remoteItem", root)
    if not isinstance(root_item.get("folder"), dict):
        raise GraphError("The shared OneDrive link must point to a folder")
    reference = root_item.get("parentReference") or {}
    drive_id = reference.get("driveId")
    folder_id = root_item.get("id")
    if not drive_id or not folder_id:
        raise GraphError("Microsoft did not return the shared folder identity")
    if parts and str(root_item.get("name", "")).casefold() == parts[0].casefold():
        parts = parts[1:]
    for part in parts:
        listed = folder_children(client_id, drive_id, folder_id)
        matches = [item for item in listed
                   if isinstance(item.get("folder"), dict) and item.get("name") == part]
        if len(matches) != 1:
            raise GraphError("Shared archive subfolder not found: " + part)
        folder = matches[0]
        drive_id = (folder.get("parentReference") or {}).get("driveId") or drive_id
        folder_id = folder.get("id")
        if not folder_id:
            raise GraphError("Shared archive folder has no identifier")
    return folder_children(client_id, drive_id, folder_id)


def folder_children(client_id, drive_id, item_id):
    return children(client_id, "/drives/" + quote(drive_id, safe="") +
                    "/items/" + quote(item_id, safe="") + "/children")


YEAR = re.compile(r"20[0-9]{2}\Z")
MONTH = re.compile(r"(?:0[1-9]|1[0-2])\Z")
DVR_ID = re.compile(r"[0-9a-f]{32}\Z")
VIDEO = re.compile(r"recording\.(?:mkv|mp4|ts)\Z", re.IGNORECASE)
ARCHIVE_MAX_FOLDERS = 512
ARCHIVE_MAX_RECORDINGS = 2000


def _display_title(value, fallback):
    """Bounded TVHeadend language/old Python-literal title normalization."""
    if isinstance(value, str) and len(value) <= 1024:
        if value.strip().startswith("{") and value.strip().endswith("}"):
            try:
                value = ast.literal_eval(value.strip())
            except (ValueError, SyntaxError, TypeError, RecursionError):
                pass
    if isinstance(value, dict):
        for language in ("eng", "en", "und", "default"):
            label = value.get(language)
            if isinstance(label, str) and label.strip():
                return label.strip()[:160]
        for label in value.values():
            if isinstance(label, str) and label.strip():
                return label.strip()[:160]
    if isinstance(value, str) and value.strip() and len(value) <= 1024:
        return value.strip()[:160]
    return fallback


def archive_recordings(client_id, roots):
    """Flatten only the known YEAR/MONTH/DVR-ID structure, never arbitrary paths.

    Microsoft delegated login still controls the drive permissions; this code
    only lists metadata already available via that account's Graph access.
    """
    if not isinstance(roots, list):
        raise GraphError("Invalid archive folder listing")
    pending = deque()
    for folder in roots:
        name = folder.get("name")
        ref = folder.get("parentReference") or {}
        drive_id = ref.get("driveId")
        if (isinstance(folder.get("folder"), dict) and
                isinstance(name, str) and YEAR.fullmatch(name) and
                isinstance(drive_id, str) and drive_id and
                isinstance(folder.get("id"), str)):
            pending.append((0, name, "", folder["id"], drive_id, ""))
    rows = []
    requests = 0
    seen = set()
    while pending:
        level, year, month, folder_id, drive_id, dvr_guid = pending.popleft()
        identity = (drive_id, folder_id)
        if identity in seen:
            continue
        seen.add(identity)
        requests += 1
        if requests > ARCHIVE_MAX_FOLDERS:
            raise GraphError("Archive has too many folders to list safely")
        records = folder_children(client_id, drive_id, folder_id)
        if level < 2:
            for item in records:
                value = item.get("name")
                ref = item.get("parentReference") or {}
                next_drive = ref.get("driveId") or drive_id
                if (not isinstance(item.get("folder"), dict) or
                        not isinstance(value, str) or
                        not isinstance(item.get("id"), str) or
                        not isinstance(next_drive, str)):
                    continue
                if level == 0 and MONTH.fullmatch(value):
                    pending.append((1, year, value, item["id"], next_drive, ""))
                elif level == 1 and DVR_ID.fullmatch(value):
                    pending.append((2, year, month, item["id"], next_drive, value))
            continue
        video = next((item for item in records
                      if isinstance(item.get("file"), dict) and
                      isinstance(item.get("name"), str) and
                      VIDEO.fullmatch(item["name"]) and
                      isinstance(item.get("id"), str) and
                      type(item.get("size")) is int and item["size"] > 0), None)
        if video is None:
            continue
        fallback = "Recording " + dvr_guid[:8]
        title = fallback
        manifest_file = next((item for item in records
                              if item.get("name") == "manifest.json" and
                              isinstance(item.get("file"), dict) and
                              isinstance(item.get("id"), str)), None)
        if manifest_file:
            try:
                manifest = read_manifest(client_id, drive_id, manifest_file["id"])
                if (manifest.get("dvr_id") == dvr_guid and
                        manifest.get("recording_filename") == video["name"] and
                        manifest.get("size") == video["size"]):
                    title = _display_title(manifest.get("title"), fallback)
            except (GraphError, ValueError, OSError, KeyError, TypeError):
                pass  # Missing metadata changes the label, never access.
        ref = video.get("parentReference") or {}
        actual_drive = ref.get("driveId") or drive_id
        if not isinstance(actual_drive, str) or not actual_drive:
            continue
        rows.append({
            "name": title + " (" + year + "-" + month + ")",
            "archive_video": True,
            "id": video["id"],
            "parentReference": {"driveId": actual_drive},
            "size": video["size"],
        })
        if len(rows) > ARCHIVE_MAX_RECORDINGS:
            raise GraphError("Archive has too many recordings to list safely")
    return sorted(rows, key=lambda item: item["name"].casefold())


def download(client_id, drive_id, item_id):
    info = get(client_id, "/drives/" + quote(drive_id, safe="") +
               "/items/" + quote(item_id, safe=""))
    url = info.get("@microsoft.graph.downloadUrl")
    size = info.get("size")
    if not isinstance(url, str) or urlsplit(url).scheme != "https":
        raise GraphError("OneDrive download URL unavailable")
    if not isinstance(size, int) or size < 0:
        raise GraphError("OneDrive size unavailable")
    return url, size


def read_manifest(client_id, drive_id, item_id):
    url, size = download(client_id, drive_id, item_id)
    if size > 131072:
        raise GraphError("Manifest too large")
    with urlopen(Request(url), timeout=30) as reply:
        raw = reply.read(131073)
    if len(raw) > 131072:
        raise GraphError("Manifest too large")
    result = json.loads(raw)
    if not isinstance(result, dict) or result.get("schema") != 1:
        raise GraphError("Invalid archive manifest")
    return result
