"""Browse private TVHeadend OneDrive recordings; Microsoft sign-in is per Kodi device."""
import sys
from urllib.parse import parse_qs, urlencode, quote
from urllib.request import urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import auth, graph

ADDON = xbmcaddon.Addon("plugin.video.tvhonedrive")
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PORT = 57443


def uri(action, **arguments):
    return BASE + "?" + urlencode({"action": action, **arguments})


def entry(label, action, folder=True, playable=False, **arguments):
    item = xbmcgui.ListItem(label=label)
    if playable:
        item.setProperty("IsPlayable", "true")
        item.setMimeType("video/x-matroska")
        item.setContentLookup(False)
    xbmcplugin.addDirectoryItem(HANDLE, uri(action, **arguments), item, isFolder=folder)


def finish(success=True):
    xbmcplugin.endOfDirectory(HANDLE, succeeded=success, cacheToDisc=False)


def home():
    account = "Signed in" if auth.load_tokens().get("refresh_token") else "Not signed in"
    entry("Archive recordings", "root")
    entry("Microsoft account sign-in (" + account + ")", "login")
    entry("Connection diagnostics", "diagnostics")
    entry("Sign out", "logout")
    entry("Add-on settings", "settings")
    finish()


def login():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Microsoft OneDrive", "Requesting sign-in code...")
    try:
        def show_code(url, code):
            dialog.update(0, "On your phone or computer visit:\n" + str(url) +
                          "\n\nEnter this code: " + str(code) +
                          "\n\nWaiting for authorization...")
        auth.device_authorize(ADDON.getSetting("client_id").strip(),
                              show_code, dialog.iscanceled)
        xbmcgui.Dialog().ok("OneDrive", "Sign-in completed successfully.")
    except auth.AuthError as exc:
        xbmcgui.Dialog().ok("OneDrive sign-in", str(exc))
    finally:
        dialog.close()
    finish()


def browse(folder=None, drive=None):
    client_id = ADDON.getSetting("client_id").strip()
    if not auth.load_tokens().get("refresh_token"):
        xbmcgui.Dialog().ok("OneDrive", "Choose Microsoft account sign-in first.")
        finish(False)
        return
    try:
        if folder is None:
            shared_link = ADDON.getSetting("share_url").strip()
            if shared_link:
                records = graph.shared_archive(
                    client_id, shared_link, ADDON.getSetting("shared_subfolder"))
            else:
                records = graph.owner_root(client_id, ADDON.getSetting("archive_path"))
        else:
            records = graph.folder_children(client_id, drive, folder)
        xbmcplugin.setContent(HANDLE, "files")
        for item in sorted(records, key=lambda x: (not bool(x.get("folder")),
                                                   x.get("name", "").lower())):
            name = item.get("name", "")
            identifier = item.get("id")
            drive_id = (item.get("parentReference") or {}).get("driveId") or drive
            if not identifier or not drive_id:
                continue
            if "folder" in item:
                entry(name, "folder", folder=True, item=identifier, drive=drive_id)
            elif name.lower().endswith((".mkv", ".mp4", ".ts")):
                entry(name, "play", folder=False, playable=True,
                      item=identifier, drive=drive_id)
        finish()
    except (auth.AuthError, graph.GraphError, OSError) as exc:
        xbmcgui.Dialog().ok("OneDrive archive", str(exc))
        finish(False)


def play(drive, item):
    try:
        with urlopen("http://127.0.0.1:" + str(PORT) + "/health", timeout=2) as health:
            if health.status != 200:
                raise OSError("Streaming service unavailable")
        address = ("http://127.0.0.1:" + str(PORT) + "/play/" +
                   quote(drive, safe="") + "/" + quote(item, safe="") +
                   "?" + urlencode({"key": auth.proxy_key()}))
        video = xbmcgui.ListItem(path=address)
        video.setMimeType("video/x-matroska")
        video.setContentLookup(False)
        xbmcplugin.setResolvedUrl(HANDLE, True, video)
    except OSError:
        xbmcgui.Dialog().ok("OneDrive", "Local playback service is not running. Restart Kodi.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def diagnostics():
    try:
        with urlopen("http://127.0.0.1:" + str(PORT) + "/health", timeout=2) as reply:
            status = "Running" if reply.status == 200 else "Unavailable"
    except OSError:
        status = "Unavailable"
    connected = "Yes" if auth.load_tokens().get("refresh_token") else "No"
    xbmcgui.Dialog().ok("TVHeadend OneDrive", "Pilot build: 0.2.3" +
                         "\nLocal playback service: " + status +
                         "\nMicrosoft account connected: " + connected)
    finish()


def main():
    arguments = parse_qs(sys.argv[2][1:])
    action = arguments.get("action", ["home"])[0]
    if action == "home":
        home()
    elif action == "settings":
        ADDON.openSettings()
        finish()
    elif action == "login":
        login()
    elif action == "root":
        browse()
    elif action == "folder":
        browse(arguments.get("item", [""])[0], arguments.get("drive", [""])[0])
    elif action == "play":
        play(arguments.get("drive", [""])[0], arguments.get("item", [""])[0])
    elif action == "diagnostics":
        diagnostics()
    elif action == "logout":
        if xbmcgui.Dialog().yesno("OneDrive", "Sign out this Kodi device?"):
            auth.sign_out()
        finish()
    else:
        finish(False)


if __name__ == "__main__":
    main()
